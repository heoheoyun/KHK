package com.moapet.controller;

import com.moapet.dto.Product;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * ProductServlet: 카테고리별로 수동으로 정의된 상품 리스트를 생성하여
 * productList.jsp로 전달하는 서블릿
 */
@WebServlet(name = "ProductServlet", urlPatterns = {"/shop/productList"})
public class ProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String category = request.getParameter("category");
        if (category == null || category.isEmpty()) {
            category = "all";
        }

        // context path 가져오기 (이미지 URL 처리용)
        String context = request.getContextPath();
        List<Product> products = new ArrayList<>();

        switch (category) {
            case "사료":
                addFood(products, context);
                break;
            case "간식":
                addSnack(products, context);
                break;
            case "장난감":
                addToy(products, context);
                break;
            case "옷":
                addCloth(products, context);
                break;
            case "집":
                addHouse(products, context);
                break;
            case "all":
            default:
                addFood(products, context);
                addSnack(products, context);
                addToy(products, context);
                addCloth(products, context);
                addHouse(products, context);
                break;
        }

        request.setAttribute("productList", products);
        request.getRequestDispatcher("/shop/productList.jsp")
               .forward(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    private void addFood(List<Product> list, String ctx) {
        list.add(new Product(101, "사료1", "사료", 15000, ctx + "/images/food1.jpg"));
        list.add(new Product(102, "사료2", "사료", 16000, ctx + "/images/food2.jpg"));
        list.add(new Product(103, "사료3", "사료", 14000, ctx + "/images/food3.jpg"));
        list.add(new Product(104, "사료4", "사료", 17000, ctx + "/images/food4.jpg"));
        list.add(new Product(105, "사료5", "사료", 15500, ctx + "/images/food5.jpg"));
    }

    private void addSnack(List<Product> list, String ctx) {
        list.add(new Product(201, "간식1", "간식", 5000, ctx + "/images/snack1.jpg"));
        list.add(new Product(202, "간식2", "간식", 5500, ctx + "/images/snack2.jpg"));
        list.add(new Product(203, "간식3", "간식", 5200, ctx + "/images/snack3.jpg"));
        list.add(new Product(204, "간식4", "간식", 6000, ctx + "/images/snack4.jpg"));
        list.add(new Product(205, "간식5", "간식", 5300, ctx + "/images/snack5.jpg"));
    }

    private void addToy(List<Product> list, String ctx) {
        list.add(new Product(301, "장난감1", "장난감", 12000, ctx + "/images/toy1.jpg"));
        list.add(new Product(302, "장난감2", "장난감", 15000, ctx + "/images/toy2.jpg"));
        list.add(new Product(303, "장난감3", "장난감", 13000, ctx + "/images/toy3.jpg"));
        list.add(new Product(304, "장난감4", "장난감", 14000, ctx + "/images/toy4.jpg"));
        list.add(new Product(305, "장난감5", "장난감", 12500, ctx + "/images/toy5.jpg"));
    }

    private void addCloth(List<Product> list, String ctx) {
        list.add(new Product(401, "옷1", "옷", 20000, ctx + "/images/cloth1.jpg"));
        list.add(new Product(402, "옷2", "옷", 22000, ctx + "/images/cloth2.jpg"));
        list.add(new Product(403, "옷3", "옷", 21000, ctx + "/images/cloth3.jpg"));
        list.add(new Product(404, "옷4", "옷", 23000, ctx + "/images/cloth4.jpg"));
        list.add(new Product(405, "옷5", "옷", 20500, ctx + "/images/cloth5.jpg"));
    }

    private void addHouse(List<Product> list, String ctx) {
        list.add(new Product(501, "집1", "집", 45000, ctx + "/images/house1.jpg"));
        list.add(new Product(502, "집2", "집", 48000, ctx + "/images/house2.jpg"));
        list.add(new Product(503, "집3", "집", 46000, ctx + "/images/house3.jpg"));
        list.add(new Product(504, "집4", "집", 50000, ctx + "/images/house4.jpg"));
        list.add(new Product(505, "집5", "집", 47000, ctx + "/images/house5.jpg"));
    }
}