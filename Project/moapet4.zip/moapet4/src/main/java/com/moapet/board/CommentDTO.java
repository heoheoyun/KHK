// ✅ CommentDTO.java
package com.moapet.board;

// 댓글 정보를 담는 DTO 클래스
public class CommentDTO {
    private int id;            // 댓글 ID
    private int boardId;       // 연결된 게시글 ID
    private String writer;     // 작성자
    private String content;    // 댓글 내용
    private Integer parentId;  // 대댓글일 경우 부모 댓글 ID
    private String createdAt;  // 작성일시

    public CommentDTO() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getBoardId() { return boardId; }
    public void setBoardId(int boardId) { this.boardId = boardId; }

    public String getWriter() { return writer; }
    public void setWriter(String writer) { this.writer = writer; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public Integer getParentId() { return parentId; }
    public void setParentId(Integer parentId) { this.parentId = parentId; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
}
