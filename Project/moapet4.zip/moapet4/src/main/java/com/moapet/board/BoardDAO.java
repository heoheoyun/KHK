// ✅ BoardDAO.java
package com.moapet.board;

import java.sql.*;
import java.util.*;
import com.moapet.util.DBUtil;

// 게시판 관련 DB 작업을 처리하는 DAO 클래스
public class BoardDAO {

    // 게시글 등록 메서드
    public int insertBoard(BoardDTO board) {
        int result = 0;
        String sql = "INSERT INTO board (board_type, title, content, region, writer) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            // 게시글 데이터 바인딩
            pstmt.setString(1, board.getBoardType());
            pstmt.setString(2, board.getTitle());
            pstmt.setString(3, board.getContent());
            pstmt.setString(4, board.getRegion());
            pstmt.setString(5, board.getWriter());

            result = pstmt.executeUpdate();  // SQL 실행
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    // 게시글 목록 조회 (게시판 타입, 지역 필터, 정렬조건 포함)
    public List<BoardDTO> getBoardList(String boardType, String region, String order) {
        List<BoardDTO> list = new ArrayList<>();
        String sql = "SELECT * FROM board WHERE board_type=?";

        if (region != null && !region.isEmpty()) {
            sql += " AND region=?";  // 지역 필터 추가
        }

        if ("hit".equals(order)) {
            sql += " ORDER BY hit DESC";  // 조회순 정렬
        } else {
            sql += " ORDER BY created_at DESC";  // 최신순 정렬
        }

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, boardType);
            if (region != null && !region.isEmpty()) {
                pstmt.setString(2, region);
            }

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                BoardDTO board = new BoardDTO();
                board.setId(rs.getInt("id"));
                board.setBoardType(rs.getString("board_type"));
                board.setTitle(rs.getString("title"));
                board.setContent(rs.getString("content"));
                board.setRegion(rs.getString("region"));
                board.setWriter(rs.getString("writer"));
                board.setHit(rs.getInt("hit"));
                board.setCreatedAt(rs.getString("created_at"));
                board.setUpdatedAt(rs.getString("updated_at"));
                list.add(board);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // 게시글 상세 조회 (조회수 증가 포함 선택)
    public BoardDTO getBoardDetail(int id, boolean increaseHit) {
        BoardDTO board = null;

        try (Connection conn = DBUtil.getConnection()) {

            // 조회수 증가 처리
            if (increaseHit) {
                String hitSql = "UPDATE board SET hit = hit + 1 WHERE id=?";
                try (PreparedStatement hitStmt = conn.prepareStatement(hitSql)) {
                    hitStmt.setInt(1, id);
                    hitStmt.executeUpdate();
                }
            }

            // 게시글 조회
            String sql = "SELECT * FROM board WHERE id=?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, id);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    board = new BoardDTO();
                    board.setId(rs.getInt("id"));
                    board.setBoardType(rs.getString("board_type"));
                    board.setTitle(rs.getString("title"));
                    board.setContent(rs.getString("content"));
                    board.setRegion(rs.getString("region"));
                    board.setWriter(rs.getString("writer"));
                    board.setHit(rs.getInt("hit"));
                    board.setCreatedAt(rs.getString("created_at"));
                    board.setUpdatedAt(rs.getString("updated_at"));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return board;
    }
}
