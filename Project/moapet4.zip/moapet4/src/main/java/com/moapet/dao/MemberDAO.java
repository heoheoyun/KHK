package com.moapet.dao;

import com.moapet.dto.MemberDTO;
import com.moapet.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class MemberDAO {

    // 회원 가입 (INSERT)
    public int insertMember(MemberDTO member) {
        int result = 0;
        String sql = "INSERT INTO member (member_id, password, name, phone, zipcode, address, detail_address, role, status) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, member.getMemberId());
            pstmt.setString(2, member.getPassword()); // 암호화된 비밀번호
            pstmt.setString(3, member.getName());
            pstmt.setString(4, member.getPhone());
            pstmt.setString(5, member.getZipcode());
            pstmt.setString(6, member.getAddress());
            pstmt.setString(7, member.getDetailAddress());
            pstmt.setString(8, member.getRole());
            pstmt.setString(9, member.getStatus());

            result = pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    // TODO: 로그인용 회원 조회 등 기능 추가 가능
}
