// ✅ BoardFileDTO.java
package com.moapet.board;

// 게시글에 첨부된 파일 정보를 담는 DTO 클래스
public class BoardFileDTO {
    private int id;              // 파일 ID
    private int boardId;         // 연결된 게시글 ID
    private String originalName; // 업로드된 원본 파일 이름
    private String storedName;   // 서버에 저장된 파일 이름
    private String uploadedAt;   // 업로드 일시

    public BoardFileDTO() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getBoardId() { return boardId; }
    public void setBoardId(int boardId) { this.boardId = boardId; }

    public String getOriginalName() { return originalName; }
    public void setOriginalName(String originalName) { this.originalName = originalName; }

    public String getStoredName() { return storedName; }
    public void setStoredName(String storedName) { this.storedName = storedName; }

    public String getUploadedAt() { return uploadedAt; }
    public void setUploadedAt(String uploadedAt) { this.uploadedAt = uploadedAt; }
}
