// ✅ CommentDAO.java
package com.moapet.board;

import java.sql.*;
import java.util.*;
import com.moapet.util.DBUtil;

// 댓글 관련 DB 작업을 처리하는 DAO 클래스
public class CommentDAO {

    // 댓글 등록
    public int insertComment(CommentDTO comment) {
        int result = 0;
        String sql = "INSERT INTO comment (board_id, writer, content, parent_id) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, comment.getBoardId());
            pstmt.setString(2, comment.getWriter());
            pstmt.setString(3, comment.getContent());

            if (comment.getParentId() != null) {
                pstmt.setInt(4, comment.getParentId());
            } else {
                pstmt.setNull(4, Types.INTEGER);
            }

            result = pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    // 댓글 목록 조회 (특정 게시글 기준)
    public List<CommentDTO> getCommentsByBoardId(int boardId) {
        List<CommentDTO> list = new ArrayList<>();
        String sql = "SELECT * FROM comment WHERE board_id=? ORDER BY created_at ASC";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, boardId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                CommentDTO comment = new CommentDTO();
                comment.setId(rs.getInt("id"));
                comment.setBoardId(rs.getInt("board_id"));
                comment.setWriter(rs.getString("writer"));
                comment.setContent(rs.getString("content"));
                comment.setParentId(rs.getObject("parent_id") != null ? rs.getInt("parent_id") : null);
                comment.setCreatedAt(rs.getString("created_at"));
                list.add(comment);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // 댓글 삭제 (관리자 또는 작성자)
    public int deleteComment(int commentId) {
        int result = 0;
        String sql = "DELETE FROM comment WHERE id=?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, commentId);
            result = pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }
}
