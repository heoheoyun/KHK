// ✅ BoardDTO.java
package com.moapet.board;

// 게시판 글 데이터를 담는 DTO 클래스
public class BoardDTO {
    private int id;                 // 글 번호 (PK)
    private String boardType;      // 게시판 종류 (ADOPTION, CARE)
    private String title;          // 글 제목
    private String content;        // 글 내용
    private String region;         // 지역명 (예: 서울, 제주 등)
    private String writer;         // 작성자
    private int hit;               // 조회수
    private String createdAt;      // 작성일시
    private String updatedAt;      // 수정일시

    public BoardDTO() {}

    // getter/setter 메서드들
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getBoardType() { return boardType; }
    public void setBoardType(String boardType) { this.boardType = boardType; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }

    public String getWriter() { return writer; }
    public void setWriter(String writer) { this.writer = writer; }

    public int getHit() { return hit; }
    public void setHit(int hit) { this.hit = hit; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

    public String getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(String updatedAt) { this.updatedAt = updatedAt; }
}
