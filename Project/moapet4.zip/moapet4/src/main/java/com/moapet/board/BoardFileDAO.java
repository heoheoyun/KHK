// ✅ BoardFileDAO.java
package com.moapet.board;

import java.sql.*;
import java.util.*;
import com.moapet.util.DBUtil;

// 첨부파일 관련 DB 작업을 처리하는 DAO 클래스
public class BoardFileDAO {

    // 파일 정보 저장
    public int insertFile(BoardFileDTO file) {
        int result = 0;
        String sql = "INSERT INTO board_file (board_id, original_name, stored_name) VALUES (?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, file.getBoardId());
            pstmt.setString(2, file.getOriginalName());
            pstmt.setString(3, file.getStoredName());

            result = pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    // 게시글에 연결된 모든 파일 조회
    public List<BoardFileDTO> getFilesByBoardId(int boardId) {
        List<BoardFileDTO> list = new ArrayList<>();
        String sql = "SELECT * FROM board_file WHERE board_id = ? ORDER BY uploaded_at ASC";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, boardId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                BoardFileDTO file = new BoardFileDTO();
                file.setId(rs.getInt("id"));
                file.setBoardId(rs.getInt("board_id"));
                file.setOriginalName(rs.getString("original_name"));
                file.setStoredName(rs.getString("stored_name"));
                file.setUploadedAt(rs.getString("uploaded_at"));
                list.add(file);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // 파일 삭제
    public int deleteFile(int fileId) {
        int result = 0;
        String sql = "DELETE FROM board_file WHERE id=?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, fileId);
            result = pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }
}
